from django.apps import AppConfig


class RegextoolConfig(AppConfig):
    name = 'regexTool'
